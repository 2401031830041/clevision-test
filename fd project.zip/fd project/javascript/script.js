const students = [
  { name: 'Aarav', marks: 78, passed: true, subject: 'Math' },
  { name: 'Diya', marks: 42, passed: false, subject: 'Science' },
  { name: 'Kabir', marks: 88, passed: true, subject: 'Math' },
  { name: 'Meera', marks: 65, passed: true, subject: 'English' },
  { name: 'Rohan', marks: 38, passed: false, subject: 'Science' },
  { name: 'Isha', marks: 92, passed: true, subject: 'Math' },
  { name: 'Vivaan', marks: 75, passed: true, subject: 'English' },
  { name: 'Anaya', marks: 70, passed: true, subject: 'Science' }
]

const passedAndAbove70 = students.filter(student => student.passed && student.marks >= 70)
const totalMarks = passedAndAbove70.reduce((sum, student) => sum + student.marks, 0)

const toppersBySubject = Object.values(
  passedAndAbove70.reduce((topperMap, student) => {
    const subject = student.subject
    if (!topperMap[subject] || student.marks > topperMap[subject].marks) {
      topperMap[subject] = {
        name: student.name,
        marks: student.marks,
        subject: student.subject
      }
    }
    return topperMap
  }, {})
)

console.log('Filtered students:', passedAndAbove70)
console.log('Total marks:', totalMarks)
console.log('Subject toppers:', toppersBySubject)

document.body.innerHTML = `
  <h1>Passed students scoring 70 or above</h1>
  <pre>${JSON.stringify(passedAndAbove70, null, 2)}</pre>
  <h2>Total marks</h2>
  <p>${totalMarks}</p>
  <h2>Subject toppers</h2>
  <pre>${JSON.stringify(toppersBySubject, null, 2)}</pre>
`


