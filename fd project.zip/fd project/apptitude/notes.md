Q1

sol   speed= distance/time   
      speed= 60/o.75   km/h

      speed=80  km/h

Q2

sol   Original price = ₹500



Q3


sol  Next number = 42
  the distance between each num is increasingby 2


Q4


sol   GMPXFS   =    flower   its using next alfabate




Q5